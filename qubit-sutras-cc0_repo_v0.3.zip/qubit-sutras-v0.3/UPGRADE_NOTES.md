# Qubit Sutras v0.3 — upgrade notes

**October 30, 2026.** Editorial upgrade of the supplied v0.2 manuscript, read-aloud text, and v0.1 repository package. The original voice, ten-chapter order, original five sutra addresses, and CC0 dedication are retained.

## Findings and changes

| Supplied material | Finding | v0.3 result |
|---|---|---|
| Master vs repository | The master was v0.2; the bundled master and index were v0.1. | The corrected manuscript is the common source for release 0.3. |
| Machine layer | Five starter records covered only fragments of the first three chapters. | All 144 numbered sections, 10 new labs, and 19 framing passages have source-addressed records. |
| Hadamard and phase | “Creates balanced superposition” omitted the input-basis condition; Z language could confuse relative and global phase. | State-dependent gate explanations and an interference example distinguish phase from populations. |
| State descriptions | Some explanations treated every qubit as a pure vector or a local subsystem as indescribable. | Pure states, mixtures, reduced density operators, the Bloch ball, and open-system channels are distinguished. |
| Teleportation | The correction table was useful, but the circuit depended on text spacing and the expansion was split across displays. | A precise operation table, a single aligned expansion, fixed bit order, branch calculations, resource accounting, and the no-signalling average. |
| Grover | Exact rotation was called approximate; stopping and query-count conventions needed precision. | Exact angle formula, first-peak rounding, explicit overshoot, a power-of-two large example, and clarified oracle-cost scope. |
| Error correction | A syndrome appeared to uniquely identify every error; quiet checks could appear to certify a clean logical state. | Degenerate recovery classes, undetected logical operators, faulty checks, boundary weights, and model-dependent thresholds. |
| QPE, VQE, QAOA | Finite-bit output, observable eigenphase reference, estimator error, layer order, and cost signs were underdeveloped. | Three small calculations expose those assumptions and conventions. |
| QKD and Bell tests | Some glosses still attributed changed statistics directly to a thief. | Error and Bell statistics constrain protocol acceptance rather than uniquely identifying a cause. |
| QRNG | A fair histogram could be read as sufficient randomness evidence; classical physical entropy was underrepresented. | Conditional min-entropy counterexample, correlated-source limits, and explicit separation from pseudo-random generators. |
| Repeaters | The role of the middle-node outcome could be easy to miss. | All four swapping branches, their endpoint average without the record, and conditional resource tradeoffs. |
| Read-aloud adaptation | Some concise lines discarded conditions carried by the manuscript. | Ten spoken sections preserve the voice and explain the main limits in about 1,400 words. |

## Verification supplied

Eight executable ideal-model check groups cover basis changes and mixtures; teleportation with a complex input, 32 additional deterministic sample states, and an entangled reference; Grover geometry; repetition-code syndromes and the Shor code's error-correction conditions; finite-bit QPE, VQE, and a QAOA sign example; BB84 intercept-resend; CHSH and entanglement swapping; and conditional entropy examples.

The release checker covers all 173 passage records, exact source spans and hashes, retained IDs, chapter and book membership, route prerequisites, an acyclic prerequisite graph, reference resolution, schema fields, generated-file drift, consistent versions, and release fingerprints. The checks are reproducible from the included files with Python's standard library; optional PyYAML adds a second parsing route for the index.

These are selected calculations and consistency checks. They do not certify an entire security protocol, every technical passage, a physical device, or the Sanskrit register.

## Remaining work worth doing

1. Have a Sanskrit specialist review register, compounds, transliteration, and translation alignment. The original five IAST strings are retained as unreviewed; the other entries do not invent transliterations.
2. Have a quantum-information instructor review the complete technical lane and teaching sequence. The primary references are conceptual anchors, not external endorsements of this edition.
3. Audition the spoken text on the intended Alexa voice and adjust pronunciation and pauses. The current deliverable is a checked script, not an audio recording.

Optional future growth: add circuit-rendered figures, a full bilingual glossary after linguistic review, and exercises at multiple difficulty levels. Those are separate additions rather than claims about the supplied text.
