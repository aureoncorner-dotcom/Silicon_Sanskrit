#!/usr/bin/env python3
"""Refresh release file hashes after intentional edits.

The manifest alone is excluded because it cannot contain its own digest.
Python bytecode caches are not release files.
"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[1]
def main():
    files={}
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or any(part in ('.git','__pycache__') for part in path.parts) or path.name=='release-manifest.json':
            continue
        data=path.read_bytes()
        files[str(path.relative_to(ROOT))]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
    manifest={'version':'0.3','revision_date':'2026-10-30',
              'hash':'SHA-256','scope':'All release files except this manifest, Git internals, and Python bytecode caches.',
              'files':files}
    (ROOT/'release-manifest.json').write_bytes((json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(f'Wrote fingerprints for {len(files)} files')

if __name__=='__main__':
    main()
