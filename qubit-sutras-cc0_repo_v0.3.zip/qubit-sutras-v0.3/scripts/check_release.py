#!/usr/bin/env python3
"""Validate corpus coverage, source integrity, graph, and release metadata.

Python 3.9+ standard library suffices. If PyYAML is installed, YAML parsing is
checked too. This checks content consistency, not Sanskrit grammar or all physics.
"""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]
def require(ok,message):
    if not ok:
        raise AssertionError(message)
def digest(b):
    return hashlib.sha256(b).hexdigest()

def main():
    raw=(ROOT/'Qubit-Sutras_MASTER.md').read_bytes()
    text=raw.decode('utf-8');lines=text.splitlines(keepends=True)
    index=json.loads((ROOT/'Qubit-Sutras_INDEX.json').read_text())
    records=[json.loads(line) for line in (ROOT/'Qubit-Sutras_SUTRAS.jsonl').read_text().splitlines() if line.strip()]
    schema=json.loads((ROOT/'schemas/sutra.schema.json').read_text())
    require(index['version']=='0.3','index version')
    require(index['schema_version']=='1.0','schema version')
    require(index['canonical_master_sha256']==digest(raw),'master digest')
    require('version: "0.3"' in text.split('---',2)[1],'front matter version')
    require('Version zero point three' in (ROOT/'Qubit_Sutras_Alexa_Read_Aloud.txt').read_text(),'audio version')
    ids=[r['id'] for r in records]
    require(len(ids)==len(set(ids)),'duplicate record IDs')
    source_ids=re.findall(r'(?m)^<a id="((?:sutra|lab|section)\.[^"]+)"></a>$',text)
    require(ids==source_ids,'record coverage and order differ from source anchors')
    require(len(re.findall(r'(?m)^### ',text))==len(records),'an H3 passage lacks an address')
    require(sum(r['record_kind']=='sutra' for r in records)==144,'numbered sutra count')
    require(sum(r['record_kind']=='lab' for r in records)==10,'worked lab count')
    require(set(('sutra.01.001','sutra.01.002','sutra.01.008','sutra.02.009','sutra.03.015')) <= set(ids),'legacy IDs lost')
    chapters={c['id']:c for c in index['chapters']}
    require(len(chapters)==10,'chapter count')
    flattened=[key for c in index['chapters'] for key in c['record_ids']]
    require(flattened==ids,'index record membership or order')
    books=[c for b in index['books'] for c in b['chapters']]
    require(books==list(chapters),'book coverage')
    for route in index['learning_routes'].values():
        require(all(c in chapters for c in route),'unknown route chapter')
        completed=set()
        for c in route:
            require(set(chapters[c]['prerequisites']) <= completed,'route misses a required prerequisite')
            completed.add(c)
    for c in chapters.values():
        for dep in c['prerequisites']+c['recommended_context']:
            require(dep in chapters and dep!=c['id'],'invalid chapter dependency')
    visited=set();active=set()
    def visit(key):
        require(key not in active,'prerequisite cycle')
        if key in visited:
            return
        active.add(key)
        for dep in chapters[key]['prerequisites']:
            visit(dep)
        active.remove(key);visited.add(key)
    for key in chapters:
        visit(key)
    required=set(schema['required']);allowed=set(schema['properties'])
    def type_ok(value,kind):
        return {'string':isinstance(value,str),'array':isinstance(value,list),
                'object':isinstance(value,dict),'null':value is None,
                'integer':isinstance(value,int) and not isinstance(value,bool)}[kind]
    for r in records:
        require(required<=set(r)<=allowed,'record fields violate published schema: '+r['id'])
        for key,rule in schema['properties'].items():
            kinds=rule.get('type')
            if isinstance(kinds,str):kinds=[kinds]
            if kinds:require(any(type_ok(r[key],t) for t in kinds),'wrong field type: '+key)
            if 'enum' in rule:require(r[key] in rule['enum'],'enum: '+key)
            if 'const' in rule:require(r[key]==rule['const'],'constant: '+key)
        require(r['chapter'] in chapters,'unknown record chapter')
        src=r['source'];start,end=src['line_start'],src['line_end']
        require(src['path']=='Qubit-Sutras_MASTER.md','source path')
        require(1<=start<=end<=len(lines),'source line span')
        exact=''.join(lines[start-1:end])
        require(exact==r['content_markdown'],'passage differs from master: '+r['id'])
        require(digest(exact.encode())==src['content_sha256'],'passage hash: '+r['id'])
        require(src['master_sha256']==digest(raw),'record master hash: '+r['id'])
        require(src['anchor']==r['id'],'anchor mismatch')
        require(lines[start-2].strip()==f'<a id="{r["id"]}"></a>','anchor and source span')
        for ref in r['references']:
            require(ref in index['references'],'unresolved source reference')
        for dep in r['prerequisites']+r['recommended_context']:
            require(dep in chapters,'unresolved prerequisite')
        require(r['summary'].strip()!='','empty summary')
        require(len(r['latex'])==len(re.findall(r'(?m)^\$\$[ \t]*$',exact))//2,'math block coverage')
    for c in range(1,11):
        sutras=[r for r in records if r['chapter']==f'chapter.{c:02d}' and r['record_kind']=='sutra']
        require([int(r['id'].split('.')[-1]) for r in sutras]==list(range(1,len(sutras)+1)),'numbered section gap')
    require(len(re.findall(r'(?m)^\$\$[ \t]*$',text))%2==0,'unbalanced display delimiters')
    require(len(re.findall(r'(?m)^```',text))%2==0,'unbalanced code fences')
    for match in re.finditer(r'(?m)^\$\$[ \t]*\n([\s\S]*?)^\$\$[ \t]*$',text):
        body=match[1]
        require(len(re.findall(r'\\left(?:\b|[.(\[|])',body))==len(re.findall(r'\\right(?:\b|[.)\]|])',body)),
                'unbalanced paired LaTeX delimiters')
    result=subprocess.run([sys.executable,str(ROOT/'scripts/build_companions.py'),'--check'],capture_output=True,text=True)
    require(result.returncode==0,result.stderr or result.stdout)
    try:
        import yaml
    except ImportError:
        print('INFO PyYAML unavailable; deterministic YAML generation checked without optional parser')
    else:
        require(yaml.safe_load((ROOT/'Qubit-Sutras_INDEX.yaml').read_text())==index,'YAML/JSON index disagreement')
    manifest=ROOT/'release-manifest.json'
    if manifest.exists():
        data=json.loads(manifest.read_text())
        require(data['version']=='0.3','manifest version')
        actual_files={str(p.relative_to(ROOT)) for p in ROOT.rglob('*')
                      if p.is_file() and not any(part in ('.git','__pycache__') for part in p.parts) and p.name!='release-manifest.json'}
        require(actual_files==set(data['files']),'manifest coverage')
        for path,expected in data['files'].items():
            require(digest((ROOT/path).read_bytes())==expected['sha256'],'manifest hash: '+path)
            require((ROOT/path).stat().st_size==expected['bytes'],'manifest byte length: '+path)
    print(f'PASS release integrity: {len(chapters)} chapters, {len(records)} records, 144 numbered sutras, 10 labs')
    print('PASS source spans, hashes, schema fields, prerequisite graph, references, versions, and generated companions')
    return 0

if __name__=='__main__':
    try:
        sys.exit(main())
    except (AssertionError,ValueError,KeyError) as error:
        print('FAIL '+str(error),file=sys.stderr)
        sys.exit(1)
