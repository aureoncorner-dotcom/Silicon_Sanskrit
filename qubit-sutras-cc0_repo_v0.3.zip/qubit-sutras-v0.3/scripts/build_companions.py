#!/usr/bin/env python3
"""Generate synchronized companions. Python 3.9+, standard library only.

The master owns exact passages. editorial/section-notes.json owns curated English
summaries and chapter context. Generated companions must not be edited directly.
"""
from pathlib import Path
import argparse
import hashlib
import json
import re
import sys

ROOT=Path(__file__).resolve().parents[1]
MASTER='Qubit-Sutras_MASTER.md'
DEV=str.maketrans('०१२३४५६७८९','0123456789')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def yaml_text(value,indent=0):
    """Emit the project's JSON-compatible data subset as UTF-8 YAML 1.2."""
    pad=' '*indent
    def scalar(v):
        return json.dumps(v,ensure_ascii=False)
    out=[]
    if isinstance(value,dict):
        for key,v in value.items():
            if isinstance(v,(dict,list)) and v:
                out.append(pad+key+':')
                out.extend(yaml_text(v,indent+2).rstrip('\n').split('\n'))
            else:
                out.append(pad+key+': '+scalar(v))
    elif isinstance(value,list):
        for v in value:
            if isinstance(v,(dict,list)) and v:
                child=yaml_text(v,indent+2).rstrip('\n').split('\n')
                out.append(pad+'- '+child[0][indent+2:])
                out.extend(child[1:])
            else:
                out.append(pad+'- '+scalar(v))
    else:
        out.append(pad+scalar(value))
    return '\n'.join(out)+'\n'

def build():
    raw=(ROOT/MASTER).read_bytes()
    text=raw.decode('utf-8')
    lines=text.splitlines(keepends=True)
    notes=json.loads((ROOT/'editorial/section-notes.json').read_text())
    version=notes['release_version']
    if f'version: "{version}"' not in text.split('---',2)[1]:
        raise ValueError('Master and annotations have different release versions')
    chapter_defaults={c['id']:c for c in notes['chapters']}
    chapters=[]; records=[];seen=set(); c=None
    for a,line in enumerate(lines):
        anchor=re.fullmatch(r'<a id="([^"]+)"></a>\n?',line)
        if not anchor:
            continue
        key=anchor[1]
        if key in seen:
            raise ValueError('Duplicate anchor: '+key)
        seen.add(key)
        if key.startswith('chapter.'):
            c=key
            heading=lines[a+1].rstrip('\n')[3:]
            match=re.match(r'अध्याय [०-९]+ · (.*?) — (.*)',heading)
            chapter=dict(chapter_defaults[key])
            chapter.update({'title_register':match[1] if match else heading,
                            'title_in_master':heading,'anchor':key,'record_ids':[]})
            chapters.append(chapter)
            continue
        if not key.startswith(('sutra.','lab.','section.')):
            continue
        if c is None:
            raise ValueError('Section before chapter: '+key)
        start=a+1;stop=start+1
        while stop < len(lines) and not lines[stop].startswith(('<a id=','## ')):
            stop+=1
        content=''.join(lines[start:stop])
        if not content.startswith('### '):
            raise ValueError('Anchor lacks H3 heading: '+key)
        title=lines[start][4:].rstrip('\n')
        title_without_num=re.sub(r'^[०-९]+\.\s*','',title)
        if ' — ' in title_without_num:
            register,english=title_without_num.split(' — ',1)
        else:
            english=title_without_num
            register=title_without_num if re.search(r'[\u0900-\u097f]',title_without_num) else None
        annotation=notes['sections'].get(key)
        kind=key.split('.')[0]
        if annotation is None:
            if kind!='section':
                raise ValueError('Missing editorial summary: '+key)
            closing=title.startswith('Closing')
            annotation={'summary':('Poetic closing' if closing else 'Opening pedagogical frame')+
                         ' for '+chapter_defaults[c]['title_english']+'.',
                         'content_role':'poetic_framing' if closing else 'pedagogical_framing'}
        body=content.split('\n',1)[1]
        label=re.search(r'(?m)^(?:Field gloss|Field translation):[ \t]*\n',body)
        gloss=None
        if label:
            part=body[label.end():]
            gloss=re.split(r'(?m)^---\s*$|^\*\*(?:Technical|Scope) note',part,maxsplit=1)[0].strip() or None
        haystack=re.sub(r'[^a-z0-9]+',' ',(english+' '+annotation['summary']).lower())
        tags=[]
        for tag in chapter_defaults[c]['concepts']:
            needle=re.sub(r'[^a-z0-9]+',' ',tag.lower())
            if needle in haystack:
                tags.append(tag.replace(' ','_').lower())
        if not tags:
            tags=[chapter_defaults[c]['concepts'][0].replace(' ','_').lower()]
        rec={
          'schema_version':notes['schema_version'],'release_version':version,'id':key,
          'record_kind':kind,'chapter':c,'title_sanskrit':register,
          'title_iast':notes['legacy_iast'].get(key),
          'title_iast_review_status':'inherited_unreviewed' if key in notes['legacy_iast'] else 'not_supplied',
          'title_english':english,'concept_tags':tags,
          'summary':annotation['summary'],'content_role':annotation['content_role'],
          'claim_lane':'modern_quantum_information_with_poetic_pedagogy',
          'layer_rule':'Technical prose and equations govern; verse and field gloss are modern mnemonics and analogies.',
          'assumptions':chapter_defaults[c]['assumptions'],
          'context_scope':'Chapter defaults; consult the exact passage for section-specific conditions.',
          'prerequisites':chapter_defaults[c]['prerequisites'],
          'recommended_context':chapter_defaults[c]['recommended_context'],
          'references':chapter_defaults[c]['references'],
          'reference_scope':'Chapter background, not independent validation of each sentence or verse.',
          'latex':re.findall(r'(?m)^\$\$[ \t]*\n([\s\S]*?)^\$\$[ \t]*$',body),
          'monkey_gloss':gloss,'content_markdown':content,
          'source':{'path':MASTER,'anchor':key,'line_start':start+1,'line_end':stop,
                    'master_sha256':sha(raw),'content_sha256':sha(content.encode())},
          'license':'CC0-1.0','linguistic_review':'not_expert_reviewed'
        }
        records.append(rec)
        chapters[-1]['record_ids'].append(key)
    known={r['id'] for r in records}
    orphan=set(notes['sections'])-known
    if orphan:
        raise ValueError('Editorial notes without a master section: '+', '.join(sorted(orphan)))
    counts={kind:sum(r['record_kind']==kind for r in records) for kind in ('sutra','lab','section')}
    index={
      'title':'क्वबिट्-सूत्राणि · The Qubit Sutras','version':version,
      'schema_version':notes['schema_version'],'revision_date':notes['revision_date'],
      'license':'CC0-1.0','canonical_master':MASTER,'canonical_master_sha256':sha(raw),
      'records_path':'Qubit-Sutras_SUTRAS.jsonl','record_counts':counts,
      'coverage':'All H3 sections within the ten chapters; front matter, glossary, and bibliography remain in the master.',
      'claim_lane':{'primary':'Modern quantum mechanics and quantum information',
                    'interface':'Sanskrit-register mnemonics and field analogies',
                    'source_priority':'Technical prose and equations govern',
                    'historical_claim':'No claim that ancient Sanskrit texts contained quantum theory',
                    'review_status':'Editorial and selected numerical checks; no independent expert certification'},
      'learning_routes':{
        'first_encounter':['chapter.01','chapter.02','chapter.03'],
        'algorithms':['chapter.01','chapter.03','chapter.04','chapter.05'],
        'keys_and_randomness':['chapter.01','chapter.06','chapter.07','chapter.08'],
        'networks':['chapter.01','chapter.02','chapter.04','chapter.09']},
      'books':[
        {'id':'book.01','title':'Foundations','chapters':['chapter.01','chapter.02']},
        {'id':'book.02','title':'Algorithms and Protection','chapters':['chapter.03','chapter.04','chapter.05']},
        {'id':'book.03','title':'Cryptography and Randomness','chapters':['chapter.06','chapter.07','chapter.08']},
        {'id':'book.04','title':'The Network and Synthesis','chapters':['chapter.09','chapter.10']}],
      'chapters':chapters,'references':notes['references']
    }
    serialized=''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in records)
    return {'Qubit-Sutras_INDEX.yaml':yaml_text(index),
            'Qubit-Sutras_INDEX.json':json.dumps(index,ensure_ascii=False,indent=2)+'\n',
            'Qubit-Sutras_SUTRAS.jsonl':serialized},counts

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check',action='store_true',help='fail on drift without writing files')
    args=parser.parse_args()
    outputs,counts=build()
    stale=[]
    for name,content in outputs.items():
        p=ROOT/name
        if args.check:
            if not p.exists() or p.read_bytes()!=content.encode('utf-8'):
                stale.append(name)
        else:
            p.write_bytes(content.encode('utf-8'))
    if stale:
        print('STALE: '+', '.join(stale),file=sys.stderr)
        return 1
    print(('PASS synchronized companions: ' if args.check else 'Generated companions: ')+json.dumps(counts))
    return 0

if __name__=='__main__':
    sys.exit(main())
