# क्वबिट्-सूत्राणि · The Qubit Sutras

**Version 0.3 — synchronized teaching edition · October 30, 2026 · CC0-1.0**

A field guide to modern quantum information, using a Sanskrit-register mnemonic voice, conventional mathematics, plain English, and postal-route field glosses. The physics is conventional; the register is the experiment.

Start with [the master](Qubit-Sutras_MASTER.md) for the full work or [the read-aloud text](Qubit_Sutras_Alexa_Read_Aloud.txt) for a spoken adaptation of roughly 9–11 minutes, depending on voice speed. The master contains ten worked labs, questions with answers, a glossary, and research references.

## What changed

- Built from the supplied **v0.2 manuscript**, carrying its corrections forward into the formerly v0.1 repository.
- Added examples that separate coherence from a mixture, show teleportation branch corrections, expose Grover overshoot, and distinguish marginal from conditional randomness.
- Clarified syndromes and logical errors, finite-precision QPE, QAOA ordering and objective signs, QKD assumptions, and repeater outcome records.
- Expanded the five starter machine records into **144 numbered sutras, 10 worked labs, and 19 framing passages: 173 records**. Existing sutra addresses are retained.
- Added exact source spans, hashes, chapter context, a schema, reproducible generation, and selected numerical checks.

## Read by purpose

| Purpose | Chapters |
|---|---|
| First encounter | 1, 2, 3 |
| Algorithms and protection | 1, 3, 4, 5 |
| Keys and randomness | 1, 6, 7, 8 |
| Networks | 1, 2, 4, 9 |
| Synthesis | Any route, then 10 |

## Files

| File or directory | Purpose |
|---|---|
| `Qubit-Sutras_MASTER.md` | Canonical human-readable manuscript |
| `Qubit_Sutras_Alexa_Read_Aloud.txt` | Plain-text spoken adaptation, with no equations to pronounce |
| `Qubit-Sutras_INDEX.yaml` | Generated chapter map, learning routes, dependencies, references, and record membership |
| `Qubit-Sutras_INDEX.json` | Equivalent index for tools that read JSON without extra dependencies |
| `Qubit-Sutras_SUTRAS.jsonl` | Generated UTF-8 records with exact passages and curated summaries |
| `editorial/section-notes.json` | Editable summaries and chapter context used by the generator |
| `schemas/sutra.schema.json` | Machine-record field contract, schema version 1.0 |
| `appendices/APPENDIX_MACHINE_INGESTION.md` | Source hierarchy, schema details, and migration guidance |
| `examples/verify_protocols.py` | Selected ideal-model calculations using Python's standard library |
| `scripts/build_companions.py` | Deterministic companion generation and drift detection |
| `scripts/check_release.py` | Coverage, source, version, graph, and integrity checks |
| `UPGRADE_NOTES.md` | Review findings, exact scope, and remaining work |
| `provenance.json` | SHA-256 fingerprints of the three supplied inputs |
| `release-manifest.json` | SHA-256 fingerprints and sizes of release files; excludes itself |
| `LICENSE.md` | Original CC0 public-domain dedication |

## Verify and edit

Use Python 3.9 or newer from this directory. No third-party packages are required. PyYAML, if already available, adds an independent YAML-parsing check.

```bash
python3 examples/verify_protocols.py
python3 scripts/build_companions.py --check
python3 scripts/check_release.py
```

Edit the master and, when needed, `editorial/section-notes.json`. Preserve an existing anchor when its concept retains its identity. Add an annotation when adding a numbered sutra or lab, then regenerate:

```bash
python3 scripts/build_companions.py
```

After intentional edits, refresh release fingerprints with `python3 scripts/build_manifest.py`, then rerun the checks. Do not hand-edit the generated JSONL or indexes. A stable address may point to revised text; use its release version and hashes when exact bytes matter.

## Source and review status

Technical prose and equations govern the operational claims. Sanskrit-register verse is a modern mnemonic; the field gloss is an analogy. The project makes no claim that ancient Sanskrit texts contained quantum theory.

The register intentionally includes coinages and mixed-language passages. Expert Sanskrit review remains open. The numerical scripts check selected ideal examples; they are not hardware experiments, cryptographic tools, or independent certification of the whole book. The spoken adaptation has been checked as text and has not been auditioned on an Alexa device.

The supplied CC0 dedication is retained for project text and code. External research papers keep their own licenses. No attribution is required by CC0; provenance is retained to make the editorial history inspectable.

Keep the verse. Attach the receipt. The ledger remains.
