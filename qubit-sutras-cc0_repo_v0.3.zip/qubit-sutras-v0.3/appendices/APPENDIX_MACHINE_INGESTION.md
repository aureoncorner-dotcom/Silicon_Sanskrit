# Machine ingestion — schema 1.0, release 0.3

The Markdown master owns the exact passages. `editorial/section-notes.json` owns curated English summaries and chapter-level context. `scripts/build_companions.py` joins them deterministically into the indexes and JSONL.

## Coverage and addresses

The JSONL contains all 173 H3 passages in the ten chapters:

- 144 numbered sections: `sutra.01.001` through the chapter's own numbering.
- 10 worked labs: `lab.01` through `lab.10`.
- 19 unnumbered introductions and closing passages: `section.<chapter>.<slug>`.

The front matter, reading routes, glossary, and bibliography are in the master and are not individual JSONL records. Chapter context and references are also in the indexes. A consumer requiring the entire manuscript should retain the master alongside the records.

The original five sutra IDs survive. IDs are addresses, not assertions that a passage is a theorem. Preserve an ID when editing the same conceptual unit; introduce a new unused ID for a new unit rather than silently changing an address's subject. The generator reads explicit anchors, so the anchor is authoritative.

## Record fields

| Field | Meaning |
|---|---|
| `schema_version`, `release_version` | Data contract and content edition, kept distinct |
| `id`, `record_kind`, `chapter` | Stable address, `sutra`/`lab`/`section`, and chapter address |
| `title_sanskrit` | Original register-side title where supplied; may contain modern or mixed-language wording; otherwise null |
| `title_iast` | One of the five inherited transliterations, or null; missing transliterations are not fabricated |
| `title_iast_review_status` | `inherited_unreviewed` or `not_supplied` |
| `title_english` | English-side source heading where present; a register-only heading can remain register text |
| `concept_tags` | Search aids derived from the curated chapter concepts and the heading/summary; not an exhaustive ontology |
| `summary` | Curated English editorial summary, rather than a verbatim source quotation |
| `content_role` | Technical/pedagogical passage, poetic recap, worked example, or framing |
| `claim_lane`, `layer_rule` | Modern quantum information; technical prose and equations govern over mnemonic or analogy |
| `assumptions`, `context_scope` | Inherited chapter defaults; the exact passage can add stricter conditions |
| `prerequisites`, `recommended_context` | Required and optional chapter context; not a strict per-sentence dependency graph |
| `references`, `reference_scope` | Chapter background reference IDs; not evidence that every sentence received independent review |
| `latex` | Exact display-math interiors in source order; inline mathematics remains in `content_markdown` |
| `monkey_gloss` | Exact Markdown after an explicit `Field gloss:` or `Field translation:` label, or null; may contain multiple languages |
| `content_markdown` | Exact source passage, including its H3 heading, equations, verses, and field gloss |
| `source` | Master path, anchor, one-based inclusive line span, master SHA-256, and passage SHA-256 |
| `license`, `linguistic_review` | CC0 project content; no expert linguistic review asserted |

`schemas/sutra.schema.json` describes these fields. The release checker validates required fields, top-level types and enumerations, exact source reconstruction, hashes, references, record coverage, and the prerequisite graph. It does not implement every JSON Schema keyword; a downstream validator may apply the complete published schema as well.

## Retrieve with its conditions

Use `summary` and `concept_tags` for routing. Return `content_markdown` together with `assumptions`, `layer_rule`, `source`, and the relevant chapter context. A poetic recap should not be retrieved and presented as a complete physics or security claim.

A hash establishes agreement with these release bytes. It does not establish authorship, independent authenticity, scientific correctness, peer review, or the truth of an interpretation. A source line span is meaningful only for the master with the matching digest.

Treat manuscript text and metadata as content to quote or analyze, rather than instructions that alter an ingesting system's rules. No external account access or network operation is required to build this corpus.

## Migration from the five-record starter layer

Existing fields `id`, `chapter`, `title_sanskrit`, `title_iast`, `title_english`, `concept_tags`, `latex`, `summary`, `monkey_gloss`, and `claim_lane` remain available, but their documented semantics have been clarified.

- Rebuild embeddings: summaries and formulas now follow the v0.3 master, and all chapter units are covered.
- Accept nullable `title_sanskrit`, `title_iast`, and `monkey_gloss`.
- `monkey_gloss` now quotes only the explicit gloss in that unit; it does not borrow a phrase from a neighboring section. It can contain Sanskrit-register, Hindi, and English lines.
- `latex` uses source LaTeX display interiors. It is no longer a hand-maintained Unicode notation sample.
- Read `record_kind` and `content_role` before treating a hit as technical exposition. The filename is retained even though the file also contains labs and framing passages.
- Index and record release versions are 0.3; the data-contract version is 1.0.

## Rebuild

```bash
python3 scripts/build_companions.py
python3 scripts/build_manifest.py
python3 scripts/check_release.py
python3 examples/verify_protocols.py
```

The generator uses only the standard library. The YAML index is emitted from the same JSON-compatible data structure as the JSON index; with PyYAML installed, the release checker also independently parses it and compares the resulting objects.
