#!/usr/bin/env python3
"""Selected ideal-model checks for Qubit Sutras v0.3. Python 3.9+, stdlib only.

This is an educational simulator. It does not produce cryptographic randomness,
implement secure QKD, model a device's noise, or certify the entire manuscript.
Qubits are indexed from the left, beginning at zero. Products act right to left.
"""
import cmath
import math
import random

TOL = 1e-10
I = ((1, 0), (0, 1))
X = ((0, 1), (1, 0))
Y = ((0, -1j), (1j, 0))
Z = ((1, 0), (0, -1))
H = tuple(tuple(x / math.sqrt(2) for x in row) for row in ((1, 1), (1, -1)))
GATES = {'I': I, 'X': X, 'Y': Y, 'Z': Z}

def require(condition, message):
    if not condition:
        raise AssertionError(message)

def near(a, b, message='numerical mismatch', tol=TOL):
    require(abs(a - b) <= tol, f'{message}: {a!r} != {b!r}')

def vector_near(a, b):
    require(len(a) == len(b), 'vector dimensions')
    for x, y in zip(a, b):
        near(x, y)

def matrix_near(a, b):
    require(len(a) == len(b), 'matrix dimensions')
    for x, y in zip(a, b):
        vector_near(x, y)

def inner(a, b):
    return sum(complex(x).conjugate() * y for x, y in zip(a, b))

def norm2(v):
    return sum(abs(x)**2 for x in v)

def normalized(v):
    n = math.sqrt(norm2(v))
    require(n > 0, 'cannot normalize zero vector')
    return [x/n for x in v]

def tensor(a, b):
    return [x*y for x in a for y in b]

def gate(v, matrix, target):
    n = len(v).bit_length()-1
    require(2**n == len(v) and 0 <= target < n, 'gate register')
    mask = 1 << (n-target-1)
    out = [0j]*len(v)
    for i in range(len(v)):
        if not i & mask:
            j = i | mask
            out[i] = matrix[0][0]*v[i]+matrix[0][1]*v[j]
            out[j] = matrix[1][0]*v[i]+matrix[1][1]*v[j]
    return out

def cnot(v, control, target):
    n = len(v).bit_length()-1
    cmask, tmask = 1 << (n-control-1), 1 << (n-target-1)
    require(control != target, 'CNOT control equals target')
    out = [0j]*len(v)
    for i, amp in enumerate(v):
        out[i ^ tmask if i & cmask else i] = amp
    return out

def pauli(v, word):
    require(2**len(word) == len(v), 'Pauli register')
    for q, letter in enumerate(word):
        if letter != 'I':
            v = gate(v, GATES[letter], q)
    return v

def density(v):
    return [[x*complex(y).conjugate() for y in v] for x in v]

def mixture(vectors, weights):
    ds = [density(v) for v in vectors]
    n = len(vectors[0])
    return [[sum(w*d[i][j] for w,d in zip(weights,ds))
             for j in range(n)] for i in range(n)]

def uniform_density(n):
    return [[(1/n if i == j else 0) for j in range(n)] for i in range(n)]

def phase_and_mixture():
    plus, minus = normalized([1,1]), normalized([1,-1])
    vector_near(gate(plus,H,0), [1,0])
    vector_near(gate(minus,H,0), [0,1])
    near(abs(plus[0])**2, .5)
    mix = mixture([[1,0],[0,1]],[.5,.5])
    matrix_near(mix, uniform_density(2))
    matrix_near(mixture([gate([1,0],H,0),gate([0,1],H,0)],[.5,.5]), mix)
    for g in (I,X,Y,Z,H):
        cols = [[g[i][j] for i in range(2)] for j in range(2)]
        for i in range(2):
            for j in range(2):
                near(inner(cols[i],cols[j]), 1 if i == j else 0)
    print('PASS phase_and_mixture: phase visibility, basis change, mixture, unitary gates')

def teleportation():
    rng = random.Random(4317)  # deterministic sample selection, not a QRNG
    states = [[math.sqrt(3)/2, .5j]]
    states += [normalized([complex(rng.uniform(-1,1),rng.uniform(-1,1)),
                           complex(rng.uniform(-1,1),rng.uniform(-1,1))]) for _ in range(32)]
    phi = normalized([1,0,0,1])
    for psi in states:
        v = gate(cnot(tensor(psi,phi),0,1),H,0)
        branches = []
        for m1 in (0,1):
            for m2 in (0,1):
                offset = 2*(2*m1+m2)
                raw = v[offset:offset+2]
                near(norm2(raw), .25, 'teleport branch probability')
                branch = normalized(raw)
                branches.append(branch)
                if m2:
                    branch = gate(branch,X,0)
                if m1:
                    branch = gate(branch,Z,0)
                vector_near(branch,psi)
        matrix_near(mixture(branches,[.25]*4),uniform_density(2))
    # The input is itself entangled with a reference, which must survive transfer.
    v = gate(cnot(tensor(phi,phi),1,2),H,1)
    for m1 in (0,1):
        for m2 in (0,1):
            branch = [v[r*8+m1*4+m2*2+b] for r in (0,1) for b in (0,1)]
            near(norm2(branch), .25)
            branch = normalized(branch)
            if m2:
                branch = gate(branch,X,1)
            if m1:
                branch = gate(branch,Z,1)
            vector_near(branch,phi)
    print('PASS teleportation: 33 inputs x 4 branches; no-signalling average; entangled reference')

def grover_step(v, marked):
    out = list(v)
    for i in marked:
        out[i] = -out[i]
    mean = sum(out)/len(out)
    return [2*mean-x for x in out]

def grover():
    v = [.5]*4
    vector_near(grover_step(v,{3}), [0,0,0,1])
    near(abs(grover_step(grover_step(v,{3}),{3})[3])**2,.25)
    for n in (2,4,8,16,64):
        for m in (1, n//2):
            marked=set(range(m))
            theta=math.asin(math.sqrt(m/n))
            v=[1/math.sqrt(n)]*n
            for k in range(9):
                near(sum(abs(v[i])**2 for i in marked),math.sin((2*k+1)*theta)**2)
                near(norm2(v),1)
                v=grover_step(v,marked)
    print('PASS grover: N=4 certainty and overshoot; exact angle vs explicit states for 5 sizes')

def error_correction():
    psi = [0j]*8
    psi[0], psi[7] = math.sqrt(3)/2, .5j
    checks=['ZZI','IZZ']
    table=[('III',(1,1)),('XII',(-1,1)),('IXI',(-1,-1)),('IIX',(1,-1))]
    for word,syndrome in table:
        v=pauli(psi,word)
        for check,sign in zip(checks,syndrome):
            near(inner(v,pauli(v,check)),sign)
        vector_near(pauli(v,word),psi)
    for undetected in ('ZII','XXX'):
        v=pauli(psi,undetected)
        for check in checks:
            near(inner(v,pauli(v,check)),1)
        require(abs(inner(psi,v)) < 1-TOL,'logical error must change chosen state')
    # Nine-qubit Shor code: check the Knill-Laflamme conditions for 28 errors.
    zero=[0j]*512;one=[0j]*512
    for blocks in range(8):
        text=''.join('111' if blocks & (1 << (2-j)) else '000' for j in range(3))
        i=int(text,2)
        zero[i]=1/math.sqrt(8)
        one[i]=(-1)**bin(blocks).count('1')/math.sqrt(8)
    near(inner(zero,one),0)
    stabilizers=['ZZIIIIIII','IZZIIIIII','IIIZZIIII','IIIIZZIII',
                 'IIIIIIZZI','IIIIIIIZZ','XXXXXXIII','IIIXXXXXX']
    for stabilizer in stabilizers:
        vector_near(pauli(zero,stabilizer),zero)
        vector_near(pauli(one,stabilizer),one)
    words=['I'*9]
    for q in range(9):
        for p in 'XYZ':
            words.append('I'*q+p+'I'*(8-q))
    e0=[pauli(zero,w) for w in words]
    e1=[pauli(one,w) for w in words]
    for i in range(28):
        for j in range(28):
            near(inner(e0[i],e0[j]),inner(e1[i],e1[j]),'equal diagonal code matrix elements')
            near(inner(e0[i],e1[j]),0,'off-diagonal code matrix element')
    vector_near(pauli(zero,'ZIIIIIIII'),pauli(zero,'IZIIIIIII'))
    vector_near(pauli(one,'ZIIIIIIII'),pauli(one,'IZIIIIIII'))
    print('PASS error_correction: syndrome table; undetected logical errors; Shor 28 x 28 error conditions')

def qpe_distribution(phase,t):
    n=2**t
    return [abs(sum(cmath.exp(2j*math.pi*k*(phase-m/n)) for k in range(n))/n)**2
            for m in range(n)]

def phase_estimation_and_variational():
    p=qpe_distribution(3/8,3)
    for m in range(8):
        near(p[m],1 if m == 3 else 0)
    p=qpe_distribution(1/3,3)
    near(sum(p),1)
    require(max(range(8),key=lambda m:p[m]) == 3,'QPE most likely bin')
    near(p[3],.687837662589, tol=1e-11)
    for j in range(65):
        theta=2*math.pi*j/64
        v=[math.cos(theta/2),math.sin(theta/2)]
        energy=inner(v,gate(v,Z,0)).real
        near(energy,math.cos(theta))
        require(energy >= -1-TOL,'VQE bound')
    beta,gamma=math.pi/8,math.pi/2
    v=[.5, .5*cmath.exp(-1j*gamma), .5*cmath.exp(-1j*gamma), .5]
    mix=((math.cos(beta),-1j*math.sin(beta)),(-1j*math.sin(beta),math.cos(beta)))
    v=gate(gate(v,mix,0),mix,1)
    near(abs(v[1])**2+abs(v[2])**2,1,'MaxCut reward')
    near(abs(v[0])**2+abs(v[3])**2,0)
    print('PASS phase_estimation_and_variational: exact/inexact QPE; VQE bound; one-edge QAOA sign')

def bb84():
    # Condition on Alice/Bob bases matching, then enumerate Eve's measurement.
    sift_error=0
    for basis in (0,1):
        for bit in (0,1):
            psi=[1-bit,bit]
            if basis:
                psi=gate(psi,H,0)
            for eve_basis in (0,1):
                measured=gate(psi,H,0) if eve_basis else psi
                for outcome in (0,1):
                    prob=abs(measured[outcome])**2
                    resend=[1-outcome,outcome]
                    if eve_basis:
                        resend=gate(resend,H,0)
                    bob=gate(resend,H,0) if basis else resend
                    error=abs(bob[1-bit])**2
                    sift_error += .125*prob*error
    near(sift_error,.25)
    near((1-sift_error)**20,.003171211938934,tol=1e-14)
    print('PASS bb84: exact intercept-resend enumeration gives 25% sifted errors')

def bell_and_swapping():
    phi=normalized([1,0,0,1])
    b1=tuple(tuple((Z[i][j]+X[i][j])/math.sqrt(2) for j in range(2)) for i in range(2))
    b2=tuple(tuple((Z[i][j]-X[i][j])/math.sqrt(2) for j in range(2)) for i in range(2))
    corr=[inner(phi,gate(gate(phi,b,1),a,0)).real
          for a,b in ((Z,b1),(Z,b2),(X,b1),(X,b2))]
    vector_near(corr,[1/math.sqrt(2)]*3+[-1/math.sqrt(2)])
    near(corr[0]+corr[1]+corr[2]-corr[3],2*math.sqrt(2))
    v=gate(cnot(tensor(phi,phi),1,2),H,1)
    branches=[]
    for m1 in (0,1):
        for m2 in (0,1):
            raw=[v[a*8+m1*4+m2*2+b] for a in (0,1) for b in (0,1)]
            near(norm2(raw),.25)
            branch=normalized(raw)
            branches.append(branch)
            if m2:
                branch=gate(branch,X,1)
            if m1:
                branch=gate(branch,Z,1)
            vector_near(branch,phi)
    matrix_near(mixture(branches,[.25]*4),uniform_density(4))
    print('PASS bell_and_swapping: CHSH 2 sqrt(2); all swap branches; unconditioned endpoints I/4')

def randomness():
    joint={(0,0):.5,(1,1):.5}
    marginal={x:sum(p for (xx,e),p in joint.items() if x == xx) for x in (0,1)}
    local_h=-math.log2(max(marginal.values()))
    p_guess=sum(max(joint.get((x,e),0) for x in (0,1)) for e in (0,1))
    conditional_h=-math.log2(p_guess)
    near(local_h,1);near(conditional_h,0)
    p=.6
    near(-math.log2(p),.7369655941662062)
    q01=p*(1-p);q10=(1-p)*p
    near(q01,q10);near(q01+q10,.48);near((q01+q10)/2,.24)
    # Correlated source: every pair is either 00 or 11, so von Neumann yields no output.
    correlated={(0,0):.5,(1,1):.5}
    near(sum(prob for pair,prob in correlated.items() if pair[0] != pair[1]),0)
    print('PASS randomness: fair-but-known counterexample; min-entropy; independent-pair extractor limits')

def main():
    groups=[phase_and_mixture,teleportation,grover,error_correction,
            phase_estimation_and_variational,bb84,bell_and_swapping,randomness]
    for check in groups:
        check()
    print(f'ALL {len(groups)} IDEAL-MODEL CHECK GROUPS PASSED')

if __name__ == '__main__':
    main()
