# Put this edition in a repository

Unzip the release and use the contents of `qubit-sutras-v0.3/` as the repository root. Keep the directory structure intact.

Before committing, run the commands in the README to check the mathematical examples and release consistency. Generated indexes and JSONL belong in the same commit as their source manuscript and editorial notes.

Suggested description:

> A CC0 Sanskrit-register teaching corpus for modern quantum information, with worked examples, source-addressed records, and reproducible checks.

Suggested topics: `quantum-computing`, `quantum-information`, `sanskrit`, `pedagogy`, `rag`, `open-data`, `cc0`.

The existing CC0 dedication covers project content and code. Linked research papers retain their own rights. See the README and upgrade notes for review status.

No crown. No toll booth. The ledger remains.
